import { Component, OnInit } from '@angular/core';

import { register } from 'swiper/element/bundle'
register();

@Component({
  selector: 'app-dev',
  templateUrl: './dev.page.html',
  styleUrls: ['./dev.page.scss'],
})
export class DevPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  swiperSliderChanged(e: any) {
    console.log('changed: ', e);
  }
}
