export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAleXjYVQ6ESLYMAhwtPGGDlVa_f49MAtI",
    authDomain: "ionicv8-b8298.firebaseapp.com",
    projectId: "ionicv8-b8298",
    storageBucket: "ionicv8-b8298.appspot.com",
    messagingSenderId: "318184063478",
    appId: "1:318184063478:web:165cae177cebc67d8587d7",
    measurementId: "G-Y0Y1DPYNSP"
  }
};
