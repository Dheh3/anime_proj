// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  //inicial era => false
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAleXjYVQ6ESLYMAhwtPGGDlVa_f49MAtI",
    authDomain: "ionicv8-b8298.firebaseapp.com",
    projectId: "ionicv8-b8298",
    storageBucket: "ionicv8-b8298.appspot.com",
    messagingSenderId: "318184063478",
    appId: "1:318184063478:web:165cae177cebc67d8587d7",
    measurementId: "G-Y0Y1DPYNSP"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
